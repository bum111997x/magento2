<?php

namespace CoWell\BasicTraining\Logger;

class Logger extends \Monolog\Logger
{

}
